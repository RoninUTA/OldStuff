# AquariumPi
Scripts for automating the live stream of an aquarium with a raspberry pi/python/twitter
