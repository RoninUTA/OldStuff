#!/bin/bash
killall mjpg_streamer
sleep 3