This is a bash script written to use the twitter-streamer.py scripts in Python 2.7. 

THIS WILL NOT WORK WITH PYTHON 2.7
