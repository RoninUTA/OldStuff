# Melissa
Shell Scripts to pull and manipulate data from Melissa.com
