# DarkWeb-Weapons
Scripts used in the original data pull from 2017

Change the paths appropriately for your directory structure.
